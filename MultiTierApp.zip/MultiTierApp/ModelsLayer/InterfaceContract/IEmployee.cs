﻿using ModelsLayer.models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelsLayer.InterfaceContract
{
    public interface IEmployee
    {
        List<Employee> GetEmployees();
        void CreateEmployee(Employee emp, out int exist,out int created,out string orgid);
    }
}
