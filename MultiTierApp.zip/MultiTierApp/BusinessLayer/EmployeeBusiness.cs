﻿using ModelsLayer.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessLayer;
namespace BusinessLayer
{
    public class EmployeeBusiness
    {
        private EmployeeDataAcess dataAcess;
        public EmployeeBusiness()
        {
            dataAcess = new EmployeeDataAcess();
        }

        public List<Employee> GetEmployees()
        {
            return dataAcess.GetEmployees();
        }

        public void CreateEmployee(Employee emp, out int exist, out int created, out string orgid)
        {
            dataAcess.CreateEmployee(emp, out exist, out created, out orgid);

        }
     }
}
